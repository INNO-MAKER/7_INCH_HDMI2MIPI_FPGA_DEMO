The following files were generated for 'chipscope_ila_64' in directory
D:\work\hdmi_mipi_7inch\p1200p1080\xc16\force_1080p\xc16_p1200p1080\sp605_ddr_test\ddr_test\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_ila_64.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_ila_64.cdc
   * chipscope_ila_64.constraints/chipscope_ila_64.ucf
   * chipscope_ila_64.constraints/chipscope_ila_64.xdc
   * chipscope_ila_64.ncf
   * chipscope_ila_64.ngc
   * chipscope_ila_64.ucf
   * chipscope_ila_64.v
   * chipscope_ila_64.veo
   * chipscope_ila_64.xdc
   * chipscope_ila_64_xmdf.tcl

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * chipscope_ila_64.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_ila_64.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * chipscope_ila_64.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * chipscope_ila_64.gise
   * chipscope_ila_64.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_ila_64_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_ila_64_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

